hero="$$$Superman$$$"
print(hero.strip("$"))