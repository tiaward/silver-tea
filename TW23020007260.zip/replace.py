sentence="The!quick!brown!fox!jumps!over!the!lazy!dog!."
new_sentence=sentence.replace("!"," ")
print(new_sentence)
print(new_sentence.upper())
print(new_sentence[::-1])